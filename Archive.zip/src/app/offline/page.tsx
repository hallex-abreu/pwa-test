export default function Offline() {
    return (
      <h1>TESTE PWA OFFLINE</h1>
    );
  }
  